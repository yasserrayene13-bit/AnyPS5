#include "prx/libSceLibreSsl3/libSceLibreSsl3.hpp"

extern "C" void APS5_VABI EC_POINT_clear_free_nid_postfix(EcPoint* point) {
    EC_POINT_free_nid_postfix(point);
}
