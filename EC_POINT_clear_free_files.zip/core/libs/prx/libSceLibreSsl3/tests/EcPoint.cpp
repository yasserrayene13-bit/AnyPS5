#include "prx/libSceLibreSsl3/libSceLibreSsl3.hpp"

#include <array>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <source_location>

namespace {

void Require(bool condition, std::source_location location = std::source_location::current()) {
    if (condition) return;
    std::fprintf(stderr, "LibreSSL3 EC_POINT_clear_free check failed at line %u\n", location.line());
    std::abort();
}

constexpr int NidPrime256v1 = 415;
constexpr int NidSecp384r1 = 715;
constexpr int PointConversionUncompressed = 4;

constexpr std::array<unsigned char, 65> P256Generator {
    0x04,
    0x6b, 0x17, 0xd1, 0xf2, 0xe1, 0x2c, 0x42, 0x47, 0xf8, 0xbc, 0xe6, 0xe5, 0x63, 0xa4, 0x40, 0xf2,
    0x77, 0x03, 0x7d, 0x81, 0x2d, 0xeb, 0x33, 0xa0, 0xf4, 0xa1, 0x39, 0x45, 0xd8, 0x98, 0xc2, 0x96,
    0x4f, 0xe3, 0x42, 0xe2, 0xfe, 0x1a, 0x7f, 0x9b, 0x8e, 0xe7, 0xeb, 0x4a, 0x7c, 0x0f, 0x9e, 0x16,
    0x2b, 0xce, 0x33, 0x57, 0x6b, 0x31, 0x5e, 0xce, 0xcb, 0xb6, 0x40, 0x68, 0x37, 0xbf, 0x51, 0xf5,
};

void ClearsNull() {
    EC_POINT_clear_free_nid_postfix(nullptr);
}

void ClearsPointAtInfinity() {
    EcGroup* group = EC_GROUP_new_by_curve_name_nid_postfix(NidPrime256v1);
    Require(group != nullptr);
    EcPoint* point = EC_POINT_new_nid_postfix(group);
    Require(point != nullptr);
    unsigned char encoded = 0xff;
    Require(EC_POINT_point2oct_nid_postfix(group, point, PointConversionUncompressed, &encoded, 1, nullptr) == 1);
    Require(encoded == 0);
    EC_POINT_clear_free_nid_postfix(point);
    EC_GROUP_free_nid_postfix(group);
}

void ClearsP256Generator() {
    EcGroup* group = EC_GROUP_new_by_curve_name_nid_postfix(NidPrime256v1);
    Require(group != nullptr);
    EcPoint* point = EC_POINT_new_nid_postfix(group);
    Require(point != nullptr);
    Require(EC_POINT_oct2point_nid_postfix(group, point, P256Generator.data(), P256Generator.size(), nullptr) == 1);
    std::array<unsigned char, 65> encoded {};
    Require(EC_POINT_point2oct_nid_postfix(group, point, PointConversionUncompressed, encoded.data(), encoded.size(), nullptr) == encoded.size());
    Require(std::memcmp(encoded.data(), P256Generator.data(), encoded.size()) == 0);
    EC_POINT_clear_free_nid_postfix(point);
    EC_GROUP_free_nid_postfix(group);
}

void ClearsCopyOfGeneratedPublicKey() {
    EcKey* key = EC_KEY_new_by_curve_name_nid_postfix(NidSecp384r1);
    Require(key != nullptr);
    Require(EC_KEY_generate_key_nid_postfix(key) == 1);
    const EcGroup* group = EC_KEY_get0_group_nid_postfix(key);
    const EcPoint* publicKey = EC_KEY_get0_public_key_nid_postfix(key);
    Require(group != nullptr && publicKey != nullptr);
    std::array<unsigned char, 97> before {};
    Require(EC_POINT_point2oct_nid_postfix(group, publicKey, PointConversionUncompressed, before.data(), before.size(), nullptr) == before.size());
    EcPoint* copy = EC_POINT_new_nid_postfix(group);
    Require(copy != nullptr);
    Require(EC_POINT_oct2point_nid_postfix(group, copy, before.data(), before.size(), nullptr) == 1);
    EC_POINT_clear_free_nid_postfix(copy);
    std::array<unsigned char, 97> after {};
    Require(EC_POINT_point2oct_nid_postfix(group, publicKey, PointConversionUncompressed, after.data(), after.size(), nullptr) == after.size());
    Require(before == after);
    Require(EC_KEY_check_key_nid_postfix(key) == 1);
    EC_KEY_free_nid_postfix(key);
}

}

int main() {
    ClearsNull();
    ClearsPointAtInfinity();
    ClearsP256Generator();
    ClearsCopyOfGeneratedPublicKey();
    return 0;
}
