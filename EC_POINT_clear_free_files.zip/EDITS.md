# تعديل الملفات الأربعة الموجودة في المشروع

الملفان الجديدان (ملف المصدر وملف الاختبار، وكلاهما باسم `EcPoint.cpp`) داخل مجلد `core/` في هذه الحزمة، وترفعهما بـ **Add file ← Upload files**.
أما الملفات الأربعة التالية فهي موجودة أصلاً في المشروع، فتُعدَّل من الموقع بزر القلم ✏️ (**Edit this file**) في أعلى صفحة كل ملف.

## 1) `core/libs/prx/libSceLibreSsl3/AdditionalExports.cpp`

احذف هذه الدالة كلها **مع السطر الفارغ الذي بعدها** (تقع قبل `int APS5_VABI d2i_PKCS8_PRIV_KEY_INFO_nid_postfix() {` مباشرة):

```cpp
int APS5_VABI EC_POINT_clear_free_nid_postfix() {
    NotImplemented_nid_no_patch(__func__);
}
```

## 2) `core/libs/prx/libSceLibreSsl3/CMakeLists.txt`

أضف في **آخر الملف**، بعد آخر `endif()` وبعد سطر فارغ، هذا النص:

```cmake
target_sources(libSceLibreSsl3 PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/src/EcPoint.cpp)
if(BUILD_TESTING)
    add_test_executable(guest_libressl3_ec_point_tests ${CMAKE_CURRENT_SOURCE_DIR}/tests/EcPoint.cpp)
    target_include_directories(guest_libressl3_ec_point_tests PRIVATE ${LIBS_INCLUDE_DIR})
    target_link_libraries(guest_libressl3_ec_point_tests PRIVATE libSceLibreSsl3 libSceLibreSsl libc)
    configure_windows_unwind(guest_libressl3_ec_point_tests)
    add_test(NAME guest_libressl3_ec_point COMMAND guest_libressl3_ec_point_tests)
    set_tests_properties(guest_libressl3_ec_point PROPERTIES TIMEOUT 20)
    if(WIN32)
        set_tests_properties(guest_libressl3_ec_point PROPERTIES ENVIRONMENT_MODIFICATION
            "PATH=path_list_prepend:$<TARGET_FILE_DIR:libSceLibreSsl3>")
    endif()
endif()
```

## 3) `core/libs/prx/libSceLibreSsl3/include/Api.hpp`

استبدل هذا السطر:

```cpp
int APS5_VABI EC_POINT_clear_free_nid_postfix();
```

بهذا السطر:

```cpp
void APS5_VABI EC_POINT_clear_free_nid_postfix(EcPoint* point);
```

## 4) `docs/dev/debt/libSceLibreSsl3.md` (ثلاثة تعديلات)

**أ)** أضف هذه الفقرة (يفصلها سطر فارغ قبلها وبعدها) مباشرة قبل السطر `### Additional callable export inventory`:

```markdown
- [EC_POINT_clear_free](../../../core/libs/prx/libSceLibreSsl3/src/EcPoint.cpp) (libSceLibreSsl3) - not checked on the console. The point structure is released without being erased, where LibreSSL's `freezero` erases it; mbedtls erases the coordinates when they are freed. It calls libSceLibreSsl's `EC_POINT_free`, as LibreSSL 4.0.0 [`ec_lib.c`](https://github.com/libressl/openbsd/blob/ce488b78e0bd994780569df718596b9776ff681a/src/lib/libcrypto/ec/ec_lib.c) does, and shares its gaps.
```

**ب)** في السطر الذي يبدأ بـ `- [Additional exports]` استبدل العبارة:

`declare 97 still-unimplemented callable exports: 88 named and 9 known only by NID`

بهذه:

`declare 96 still-unimplemented callable exports: 87 named and 9 known only by NID`

**ج)** احذف صف الجدول هذا بالكامل:

```markdown
| `EC_POINT_clear_free` | `aSO3Svp7umY` |
```

## ترتيب العمل على الموقع

1. في نسختك (fork) ارفع مجلد `core` من هذه الحزمة بـ **Add file ← Upload files**، واختر **Create a new branch for this commit and start a pull request**، واكتب اسم الفرع `feat/ec-point-clear-free`. عند الوصول إلى صفحة "Open a pull request" لا تُنشئ الـ PR بعد.
2. من قائمة الفروع (أعلى الصفحة) اختر `feat/ec-point-clear-free`، ثم افتح كل ملف من الملفات الأربعة وعدّله، واختر عند الحفظ **Commit directly to the feat/ec-point-clear-free branch**.
3. بعد آخر تعديل افتح صفحة نسختك واضغط **Compare & pull request**.

اجعل رسائل الـ commit بصيغة Conventional Commits، مثل `feat(libSceLibreSsl3): implement EC_POINT_clear_free`.
